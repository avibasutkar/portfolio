import { motion } from 'motion/react';
import { GraduationCap, Calendar } from 'lucide-react';

const educationData = [
  {
    id: 1,
    title: 'B.E. in Computer Science',
    institution: '',
    year: '2022 – 2026',
    desc: 'Currently pursuing Bachelor of Engineering in Computer Science and Engineering.',
    scoreType: 'CGPA',
    score: '8.1'
  },
  {
    id: 2,
    title: 'Pre-University College (Science)',
    institution: 'D. Devaraj Urs PU Science College Shahapur, Yadgiri',
    year: 'Completed',
    desc: 'Completed Higher Secondary education in the Science stream.',
    scoreType: 'Percentage',
    score: '70%'
  },
  {
    id: 3,
    title: 'High School',
    institution: 'Sharada Vidyanikethana School Shahapur, Yadgiri',
    year: 'Completed',
    desc: 'Completed secondary education.',
    scoreType: 'Percentage',
    score: '75%'
  }
];

export default function Education() {
  return (
    <section id="education" className="py-20 px-4 sm:px-6 lg:px-8 max-w-3xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5 }}
        className="text-center mb-16"
      >
        <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">Education</h2>
        <div className="w-20 h-1 bg-blue-600 mx-auto rounded-full"></div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5 }}
        className="relative pl-8"
      >
        {/* Timeline Line */}
        <div className="absolute left-0 top-0 bottom-0 w-px bg-gray-200 dark:bg-gray-700"></div>

        {educationData.map((item) => (
          <div key={item.id} className="relative pb-10 last:pb-0">
            {/* Timeline Dot */}
            <div className="absolute left-[-37px] top-1 w-4 h-4 rounded-full bg-blue-600 border-4 border-white dark:border-gray-950 shadow"></div>
            
            <div className="glass-card rounded-2xl p-6">
              <div className="flex items-center gap-2 text-blue-600 dark:text-blue-400 mb-2">
                <GraduationCap size={20} />
                <h3 className="text-xl font-bold text-gray-900 dark:text-white">{item.title}</h3>
              </div>
              
              <div className="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400 mb-3 font-mono">
                <Calendar size={14} />
                <span>{item.year}</span>
              </div>

              {item.institution && (
                <p className="text-gray-800 dark:text-gray-200 font-medium mb-2">
                  {item.institution}
                </p>
              )}
              
              <p className="text-gray-600 dark:text-gray-400 mb-4 text-sm">
                {item.desc}
              </p>
              
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300 font-medium">
                <span>{item.scoreType}:</span>
                <span className="text-lg">{item.score}</span>
              </div>
            </div>
          </div>
        ))}
      </motion.div>
    </section>
  );
}
