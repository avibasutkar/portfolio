import { motion } from 'motion/react';
import { User, Code, BrainCircuit } from 'lucide-react';

export default function About() {
  return (
    <section id="about" className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5 }}
        className="text-center mb-16"
      >
        <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">About Me</h2>
        <div className="w-20 h-1 bg-blue-600 mx-auto rounded-full"></div>
      </motion.div>

      <div className="grid md:grid-cols-2 gap-12 items-center">
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-500 to-purple-500 rounded-2xl transform rotate-3 opacity-20 dark:opacity-30"></div>
            <div className="glass-card rounded-2xl p-8 relative">
              <h3 className="text-2xl font-semibold text-gray-900 dark:text-white mb-4">
                Hello! I'm Avinash
              </h3>
              <p className="text-gray-600 dark:text-gray-300 mb-6 leading-relaxed">
                I am a motivated and detail-oriented Computer Science & Engineering student with a strong passion for solving complex problems. My academic journey has equipped me with a solid foundation in both Software Development and Machine Learning.
              </p>
              <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                I am particularly interested in the intersection of AI, Data Science, and Web Development, striving to build intelligent, user-centric applications that make a real-world impact.
              </p>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="space-y-6"
        >
          <div className="flex items-start gap-4">
            <div className="p-3 rounded-lg bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400">
              <User size={24} />
            </div>
            <div>
              <h4 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">Dedicated Student</h4>
              <p className="text-gray-600 dark:text-gray-400">Constantly learning and adapting to new technologies in the fast-paced tech landscape.</p>
            </div>
          </div>
          
          <div className="flex items-start gap-4">
            <div className="p-3 rounded-lg bg-purple-100 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400">
              <BrainCircuit size={24} />
            </div>
            <div>
              <h4 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">ML & AI Focus</h4>
              <p className="text-gray-600 dark:text-gray-400">Deep interest in Natural Language Processing, Deep Learning, and building intelligent models.</p>
            </div>
          </div>

          <div className="flex items-start gap-4">
            <div className="p-3 rounded-lg bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400">
              <Code size={24} />
            </div>
            <div>
              <h4 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">Full-Stack Capable</h4>
              <p className="text-gray-600 dark:text-gray-400">Bridging the gap between powerful backend models and intuitive frontend interfaces.</p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
