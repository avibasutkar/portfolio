export default function Footer() {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="py-8 text-center border-t border-gray-200 dark:border-gray-800">
      <p className="text-gray-600 dark:text-gray-400">
        © {currentYear} Avinash Basutkar. All rights reserved.
      </p>
      <p className="text-sm text-gray-500 dark:text-gray-500 mt-2">
        Built with React & Tailwind CSS
      </p>
    </footer>
  );
}
