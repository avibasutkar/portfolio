import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ExternalLink, Github, Star, BrainCircuit } from 'lucide-react';

type ProjectType = 'All' | 'ML/AI' | 'Web';

const projects = [
  {
    id: 1,
    title: 'Automatic Question Generator from Notes',
    description: 'AI-powered system that generates questions from study notes using NLP/LLMs. Extracts key concepts and generates MCQs, short answers, and descriptive questions. Useful for students and educators.',
    tech: ['Python', 'NLP', 'LLM (Gemini)', 'Streamlit'],
    category: 'ML/AI',
    featured: true,
    github: '#',
    demo: '#',
  },
  {
    id: 2,
    title: 'Lung Sound Classifier',
    description: 'CNN + LSTM model for respiratory disease detection using audio spectrograms.',
    tech: ['Deep Learning', 'CNN', 'LSTM', 'Spectrograms'],
    category: 'ML/AI',
    featured: false,
    github: '#',
  },
  {
    id: 3,
    title: 'Spam Mail Detection',
    description: 'Machine Learning-based system to classify emails as spam or not spam.',
    tech: ['Python', 'Scikit-learn', 'Machine Learning'],
    category: 'ML/AI',
    featured: false,
    github: '#',
  },
  {
    id: 4,
    title: 'Hotel Management System',
    description: 'Online booking system with room selection and management features.',
    tech: ['Web Development', 'HTML/CSS', 'JavaScript', 'SQL'],
    category: 'Web',
    featured: false,
    github: '#',
  },
];

export default function Projects() {
  const [filter, setFilter] = useState<ProjectType>('All');

  const filteredProjects = projects.filter(
    (project) => filter === 'All' || project.category === filter
  );

  return (
    <section id="projects" className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5 }}
        className="text-center mb-12"
      >
        <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">Featured Projects</h2>
        <div className="w-20 h-1 bg-blue-600 mx-auto rounded-full mb-8"></div>

        {/* Filter Buttons */}
        <div className="flex justify-center gap-4 mb-12">
          {(['All', 'ML/AI', 'Web'] as ProjectType[]).map((type) => (
            <button
              key={type}
              onClick={() => setFilter(type)}
              className={`px-6 py-2 rounded-full text-sm font-medium transition-all ${
                filter === type
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'glass text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
              }`}
            >
              {type}
            </button>
          ))}
        </div>
      </motion.div>

      <motion.div layout className="grid md:grid-cols-2 gap-8">
        <AnimatePresence mode="popLayout">
          {filteredProjects.map((project) => (
            <motion.div
              layout
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ duration: 0.3 }}
              key={project.id}
              className={`glass-card rounded-2xl overflow-hidden flex flex-col ${
                project.featured ? 'md:col-span-2 md:flex-row' : ''
              }`}
            >
              <div className={`p-8 flex flex-col justify-between flex-grow ${project.featured ? 'md:w-1/2' : ''}`}>
                <div>
                  {project.featured && (
                    <div className="flex items-center gap-2 text-yellow-500 mb-4 text-sm font-semibold tracking-wider uppercase">
                      <Star size={16} fill="currentColor" />
                      Featured Project
                    </div>
                  )}
                  <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                    {project.title}
                  </h3>
                  <p className="text-gray-600 dark:text-gray-300 mb-6 leading-relaxed">
                    {project.description}
                  </p>
                  <div className="flex flex-wrap gap-2 mb-8">
                    {project.tech.map((tech) => (
                      <span
                        key={tech}
                        className="px-3 py-1 text-xs font-medium rounded-md bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
                
                <div className="flex items-center gap-4 mt-auto">
                  {project.github && (
                    <a
                      href={project.github}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors"
                    >
                      <Github size={20} />
                      <span className="text-sm font-medium">Code</span>
                    </a>
                  )}
                  {project.demo && (
                    <a
                      href={project.demo}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 transition-colors"
                    >
                      <ExternalLink size={20} />
                      <span className="text-sm font-medium">Live Demo</span>
                    </a>
                  )}
                </div>
              </div>
              
              {/* Decorative placeholder for image */}
              {project.featured && (
                <div className="md:w-1/2 bg-gradient-to-br from-blue-500/20 to-purple-500/20 dark:from-blue-500/10 dark:to-purple-500/10 flex items-center justify-center min-h-[200px] md:min-h-full border-t md:border-t-0 md:border-l border-gray-200 dark:border-gray-700/50">
                  <div className="text-center p-6">
                    <div className="w-16 h-16 mx-auto mb-4 rounded-xl bg-blue-500/20 flex items-center justify-center text-blue-600 dark:text-blue-400">
                      <BrainCircuit size={32} />
                    </div>
                    <p className="text-sm text-gray-500 dark:text-gray-400 font-mono">AI Question Generator UI Preview</p>
                  </div>
                </div>
              )}
            </motion.div>
          ))}
        </AnimatePresence>
      </motion.div>
    </section>
  );
}
