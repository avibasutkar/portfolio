import { motion } from 'motion/react';
import { Trophy, Award, Zap, BookOpen } from 'lucide-react';

const achievements = [
  {
    icon: <Trophy className="text-yellow-500" size={24} />,
    title: '2nd Prize – EV Vehicle Presentation',
    description: 'Awarded second place for an innovative presentation on Electric Vehicles.',
  },
  {
    icon: <Zap className="text-blue-500" size={24} />,
    title: 'Participated in 24-hour Hackathon',
    description: 'Competed in an intensive 24-hour hackathon organized by Unstop.',
  },
  {
    icon: <Award className="text-purple-500" size={24} />,
    title: 'Leader in AI-Studio Hackathon',
    description: 'Led a team to build AI-powered solutions during the AI-Studio Hackathon.',
  },
  {
    icon: <BookOpen className="text-green-500" size={24} />,
    title: 'Technical Workshops',
    description: 'Completed workshops in Cloud Computing, IoT, Data Science, and CISCO Packet Tracing.',
  },
];

export default function Achievements() {
  return (
    <section id="achievements" className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-100/50 dark:bg-gray-900/20">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">Achievements & Activities</h2>
          <div className="w-20 h-1 bg-blue-600 mx-auto rounded-full"></div>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-6">
          {achievements.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="glass-card rounded-2xl p-6 flex items-start gap-4"
            >
              <div className="p-3 rounded-xl bg-white dark:bg-gray-800 shadow-sm border border-gray-100 dark:border-gray-700 shrink-0">
                {item.icon}
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">{item.title}</h3>
                <p className="text-gray-600 dark:text-gray-400 text-sm leading-relaxed">{item.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
