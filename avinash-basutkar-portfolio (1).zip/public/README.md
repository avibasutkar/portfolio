This folder contains public assets like your resume. Please upload your PDF file here and name it "Avinash_Basutkar_Resume.pdf".
